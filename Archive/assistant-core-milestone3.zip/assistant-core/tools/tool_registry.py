"""
Tool Registry
The single place where all tools are registered and dispatched.

The assistant never imports tools directly.
It calls registry.run("tool_name", input) and gets a ToolResult back.

Adding a new tool:
    1. Write a new subclass of BaseTool in tools/
    2. Import it here and add it to _build_tools()
    That's it. Nothing else in the codebase changes.
"""

import logging
from tools.base_tool import BaseTool, ToolResult
from tools.read_note import ReadNoteTool
from tools.search_vault import SearchVaultTool
from tools.list_vault import ListVaultTool
from tools.get_linked_notes import GetLinkedNotesTool

logger = logging.getLogger("assistant")


class ToolRegistry:
    """Holds all registered tools and dispatches run() calls by name."""

    def __init__(self, vault_path: str):
        self._vault_path = vault_path
        self._tools: dict[str, BaseTool] = {}
        self._build_tools()

    def _build_tools(self) -> None:
        """Instantiate and register all tools."""
        vault_tools = [
            ReadNoteTool(self._vault_path),
            SearchVaultTool(self._vault_path),
            ListVaultTool(self._vault_path),
            GetLinkedNotesTool(self._vault_path),
        ]
        for tool in vault_tools:
            self._tools[tool.name] = tool
            logger.info(f"[Registry] Registered tool: {tool.name}")

    def run(self, tool_name: str, input_data: str = "") -> ToolResult:
        """
        Execute a tool by name.

        Args:
            tool_name:  The tool's name string (e.g. 'read_note').
            input_data: The tool's primary input as a plain string.

        Returns:
            ToolResult — always, even on error (success=False).
        """
        tool = self._tools.get(tool_name)
        if tool is None:
            available = ", ".join(self._tools.keys())
            return ToolResult(
                success=False,
                output=f"Unknown tool '{tool_name}'. Available tools: {available}"
            )
        logger.info(f"[Registry] Running tool: {tool_name}")
        try:
            return tool.run(input_data)
        except Exception as exc:
            logger.error(f"[Registry] Tool '{tool_name}' raised an exception: {exc}")
            return ToolResult(success=False, output=f"Tool error: {exc}")

    def list_tools(self) -> list[dict]:
        """Return a list of tool metadata for display."""
        return [
            {"name": t.name, "description": t.description}
            for t in self._tools.values()
        ]

    @property
    def tool_names(self) -> list[str]:
        return list(self._tools.keys())
