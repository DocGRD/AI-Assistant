"""
Assistant Core — Milestone 3
Adds the Vault Access Layer on top of Milestone 2.

What's new in Milestone 3:
    - ToolRegistry initialised at startup with all vault tools
    - Tool status shown in startup diagnostics
    - New commands: vault:<tool> <input>
        vault:read    <note name or path>
        vault:search  <query text>
        vault:list    [optional subfolder]
        vault:links   <note name or path>
    - 'tools' command shows all registered tools
    - Vault tool output is also fed into the AI as context
      so the AI can reason about your notes directly
"""

from pathlib import Path

from config.config_manager import ConfigManager
from config.logger import setup_logger
from providers.provider_router import ProviderRouter
from providers.base_provider import Message, ProviderError
from tools.tool_registry import ToolRegistry


# ---------------------------------------------------------------------------
# Startup Diagnostics
# ---------------------------------------------------------------------------

def run_startup_diagnostics(
    config: ConfigManager,
    router: ProviderRouter,
    registry: ToolRegistry | None,
    logger,
) -> None:
    checks = {}

    config_path = Path(__file__).parent / "config" / "settings.json"
    checks["Config Loaded"] = config_path.exists()

    vault_path = config.get("vault_path", "")
    vault_ok = bool(vault_path) and Path(vault_path).exists()
    checks["Vault Found"] = vault_ok

    logs_dir = Path(__file__).parent / "logs"
    logs_dir.mkdir(exist_ok=True)
    checks["Logs Ready"] = logs_dir.exists()

    memory_dir = Path(__file__).parent / "memory"
    memory_dir.mkdir(exist_ok=True)
    checks["Memory Ready"] = memory_dir.exists()

    for provider_name, available in router.status().items():
        checks[f"Provider: {provider_name.capitalize()}"] = available

    tool_count = len(registry.tool_names) if registry else 0
    checks[f"Vault Tools ({tool_count})"] = tool_count > 0

    print("\n" + "=" * 44)
    print("  AI ASSISTANT — Startup Check")
    print("=" * 44)
    for check_name, passed in checks.items():
        symbol = "✓" if passed else "✗"
        print(f"  {symbol}  {check_name}")
    print("=" * 44)

    available_providers = router.available_providers
    if available_providers:
        print(f"\n  Active provider  : {config.get('default_provider', 'groq').upper()}")
        if len(available_providers) > 1:
            print(f"  Fallback provider: {config.get('fallback_provider', 'google').upper()}")
    else:
        print("\n  ✗  No providers available. Add API keys to config/settings.json.")

    print("\n  Assistant Online")
    print("=" * 44 + "\n")

    failed = [n for n, p in checks.items() if not p]
    if failed:
        logger.warning(f"Startup checks failed: {', '.join(failed)}")
    else:
        logger.info("All startup checks passed")


# ---------------------------------------------------------------------------
# System Prompt
# ---------------------------------------------------------------------------

SYSTEM_PROMPT = """You are a helpful AI development assistant integrated with Obsidian.
You help with software development, research, planning, and knowledge management.
You are concise, accurate, and practical.
When you don't know something, say so clearly.
When vault content is provided in the conversation, use it to give specific,
grounded answers rather than generic responses.
When the user asks you to search the internet, generate an optimized research
prompt they can paste into a web-based AI instead."""


# ---------------------------------------------------------------------------
# Vault command dispatcher
# ---------------------------------------------------------------------------

VAULT_COMMANDS = {
    "vault:read":   ("read_note",        "Usage: vault:read <note name or path>"),
    "vault:search": ("search_vault",     "Usage: vault:search <query text>"),
    "vault:list":   ("list_vault",       "Usage: vault:list [optional subfolder]"),
    "vault:links":  ("get_linked_notes", "Usage: vault:links <note name or path>"),
}


def handle_vault_command(
    raw: str,
    registry: ToolRegistry,
    history: list[Message],
    logger,
) -> str | None:
    """
    If raw starts with a vault: prefix, run the tool and return formatted output.
    Also appends the result to history so the AI has vault context.
    Returns None if raw is not a vault command.
    """
    parts = raw.split(None, 1)
    prefix = parts[0].lower()

    if prefix not in VAULT_COMMANDS:
        return None

    tool_name, usage = VAULT_COMMANDS[prefix]
    tool_input = parts[1].strip() if len(parts) > 1 else ""

    if not tool_input and tool_name != "list_vault":
        return f"Missing input. {usage}"

    result = registry.run(tool_name, tool_input)

    if result.success:
        # Inject vault content into conversation history so the AI sees it
        context_message = (
            f"[Vault context loaded by tool '{tool_name}']\n\n"
            f"{result.output}"
        )
        history.append(Message(role="user", content=context_message))
        history.append(Message(
            role="assistant",
            content=f"I've loaded the vault content above. Ready to help you work with it."
        ))
        logger.info(f"[Vault] '{tool_name}' result injected into conversation history")

    status = "✓" if result.success else "✗"
    return f"{status} [{tool_name}]\n\n{result.output}"


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> None:
    config   = ConfigManager()
    logger   = setup_logger(config.get("log_level", "INFO"))
    logger.info("Assistant starting — Milestone 3")

    router   = ProviderRouter(config.all())

    vault_path = config.get("vault_path", "")
    registry: ToolRegistry | None = None
    if vault_path and Path(vault_path).exists():
        registry = ToolRegistry(vault_path)
    else:
        logger.warning("Vault path not set or not found — vault tools disabled.")

    run_startup_diagnostics(config, router, registry, logger)

    if not router.available_providers:
        print("No AI providers available.")
        print("Add API keys to config/settings.json and restart.\n")
        print("  Groq   (free): https://console.groq.com")
        print("  Google (free): https://aistudio.google.com/app/apikey\n")
        return

    history: list[Message] = []

    print("Type your message and press Enter.")
    print("Vault commands : vault:read | vault:search | vault:list | vault:links")
    print("Other commands : tools | status | clear | exit\n")

    while True:
        try:
            user_input = input("You: ").strip()
        except (KeyboardInterrupt, EOFError):
            print("\nExiting.")
            logger.info("Assistant shut down via keyboard interrupt.")
            break

        if not user_input:
            continue

        # ── Built-in commands ──────────────────────────────────────────────
        if user_input.lower() in ("exit", "quit"):
            logger.info("Assistant shutting down.")
            print("Goodbye.")
            break

        if user_input.lower() == "clear":
            history.clear()
            print("[Conversation history cleared]\n")
            continue

        if user_input.lower() == "status":
            print("\n--- Provider Status ---")
            for name, available in router.status().items():
                print(f"  {'✓' if available else '✗'}  {name.capitalize()}")
            print("-----------------------\n")
            continue

        if user_input.lower() == "tools":
            if registry is None:
                print("[Vault tools not available — set vault_path in settings.json]\n")
            else:
                print("\n--- Available Vault Tools ---")
                for t in registry.list_tools():
                    print(f"  {t['name']:<22} {t['description']}")
                print("-----------------------------\n")
            continue

        # ── Vault commands ─────────────────────────────────────────────────
        if user_input.lower().startswith("vault:"):
            if registry is None:
                print("[Vault tools not available — set vault_path in settings.json]\n")
                continue
            output = handle_vault_command(user_input, registry, history, logger)
            if output is not None:
                print(f"\n{output}\n")
                continue

        # ── Normal AI chat ─────────────────────────────────────────────────
        history.append(Message(role="user", content=user_input))
        logger.info(f"User: {user_input[:80]}{'...' if len(user_input) > 80 else ''}")

        try:
            reply = router.generate(
                messages=history,
                system_prompt=SYSTEM_PROMPT,
                max_tokens=config.get("max_tokens", 2048),
                temperature=config.get("temperature", 0.7),
            )
        except ProviderError as exc:
            print(f"\n[Error] Could not get a response: {exc}\n")
            logger.error(f"Provider error: {exc}")
            history.pop()
            continue

        history.append(Message(role="assistant", content=reply))
        logger.info(f"Assistant replied ({len(reply)} chars)")
        print(f"\nAssistant: {reply}\n")


if __name__ == "__main__":
    main()
