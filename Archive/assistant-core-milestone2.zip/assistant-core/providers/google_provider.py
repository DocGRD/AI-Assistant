"""
Google AI Provider
Connects to Google AI Studio (Gemini) via the google-generativeai SDK.

Free models (as of mid-2026):
    gemini-1.5-flash      (fast, large context)
    gemini-1.5-pro        (more capable, lower quota)
    gemini-2.0-flash-exp  (experimental)

Free tier limits:
    15 requests/minute
    1,000,000 tokens/day (Flash)

Install: pip install google-generativeai
Get a free key at: https://aistudio.google.com/app/apikey
"""

import time
import logging

from providers.base_provider import (
    BaseProvider,
    Message,
    ProviderAuthError,
    ProviderError,
    ProviderRateLimitError,
)

logger = logging.getLogger("assistant")


class GoogleProvider(BaseProvider):
    """Adapter for Google AI Studio (Gemini)."""

    def __init__(self, config: dict):
        super().__init__(config)

        api_key = config.get("google_api_key", "").strip()
        if not api_key:
            raise ProviderAuthError(
                "Google API key is missing.\n"
                "Add it to config/settings.json under 'google_api_key'.\n"
                "Get a free key at https://aistudio.google.com/app/apikey"
            )

        try:
            import google.generativeai as genai
        except ImportError:
            raise ProviderError(
                "The 'google-generativeai' library is not installed.\n"
                "Run: pip install google-generativeai"
            )

        genai.configure(api_key=api_key)
        self._genai = genai
        self._model_name = config.get("google_model", "gemini-1.5-flash")

    @property
    def name(self) -> str:
        return "Google"

    def generate(
        self,
        messages: list[Message],
        system_prompt: str = "",
        max_tokens: int = 2048,
        temperature: float = 0.7,
    ) -> str:
        """Send messages to Gemini and return the response text."""

        logger.info(f"[Google] Sending request — model: {self._model_name}, messages: {len(messages)}")

        try:
            # Build model with optional system instruction
            model_kwargs = {
                "generation_config": {
                    "max_output_tokens": max_tokens,
                    "temperature": temperature,
                }
            }
            if system_prompt:
                model_kwargs["system_instruction"] = system_prompt

            model = self._genai.GenerativeModel(self._model_name, **model_kwargs)

            # Convert messages to Gemini history format
            # Gemini uses role "user" and "model" (not "assistant")
            history = []
            for msg in messages[:-1]:  # all but the last message become history
                gemini_role = "model" if msg.role == "assistant" else "user"
                history.append({"role": gemini_role, "parts": [msg.content]})

            chat = model.start_chat(history=history)

            # The last message is the current user turn
            last_message = messages[-1].content if messages else ""
            response = chat.send_message(last_message)

            reply = response.text
            logger.info(f"[Google] Response received — {len(reply)} characters")
            return reply

        except Exception as exc:
            error_text = str(exc).lower()

            if "quota" in error_text or "rate" in error_text or "429" in error_text:
                logger.warning(f"[Google] Rate limit hit: {exc}")
                raise ProviderRateLimitError(
                    "Google AI rate limit reached. The assistant will wait and retry."
                ) from exc

            if "api key" in error_text or "401" in error_text or "permission" in error_text:
                logger.error(f"[Google] Auth error: {exc}")
                raise ProviderAuthError(
                    "Google rejected the API key. Check config/settings.json → 'google_api_key'."
                ) from exc

            logger.error(f"[Google] Unexpected error: {exc}")
            raise ProviderError(f"Google AI error: {exc}") from exc

    def generate_with_retry(
        self,
        messages: list[Message],
        system_prompt: str = "",
        max_tokens: int = 2048,
        temperature: float = 0.7,
        retries: int = 3,
        wait_seconds: int = 60,
    ) -> str:
        """Retry on rate-limit errors with a wait between attempts."""
        for attempt in range(1, retries + 1):
            try:
                return self.generate(messages, system_prompt, max_tokens, temperature)
            except ProviderRateLimitError:
                if attempt < retries:
                    print(f"\n[Google] Rate limit hit. Waiting {wait_seconds}s before retry {attempt}/{retries - 1}...")
                    time.sleep(wait_seconds)
                else:
                    print("\n[Google] Rate limit hit. All retries exhausted.")
                    raise
