"""
Provider Router
Selects the right provider for each request.
Falls back to the secondary provider if the primary hits a rate limit.
The rest of the assistant never imports Groq or Google directly —
it only talks to this router.

Usage:
    router = ProviderRouter(config.all())
    reply  = router.generate(messages, system_prompt="You are a helpful assistant.")
"""

import logging
from providers.base_provider import (
    BaseProvider,
    Message,
    ProviderAuthError,
    ProviderError,
    ProviderRateLimitError,
)
from providers.groq_provider import GroqProvider
from providers.google_provider import GoogleProvider

logger = logging.getLogger("assistant")

# Registry of all known providers — add new ones here only
_PROVIDER_CLASSES: dict[str, type[BaseProvider]] = {
    "groq":   GroqProvider,
    "google": GoogleProvider,
}


class ProviderRouter:
    """
    Initializes configured providers and routes generate() calls.

    Priority:
        1. default_provider  (from settings.json)
        2. fallback_provider (from settings.json) — used on rate-limit errors

    If both fail, raises the last exception so the caller can decide.
    """

    def __init__(self, config: dict):
        self._config = config
        self._default_name  = config.get("default_provider",  "groq").lower()
        self._fallback_name = config.get("fallback_provider", "google").lower()
        self._max_tokens    = config.get("max_tokens",   2048)
        self._temperature   = config.get("temperature",  0.7)

        self._providers: dict[str, BaseProvider] = {}
        self._init_providers()

    # ------------------------------------------------------------------
    # Initialisation
    # ------------------------------------------------------------------

    def _init_providers(self) -> None:
        """Try to construct each configured provider. Log failures but don't crash."""
        for name in [self._default_name, self._fallback_name]:
            if name in self._providers:
                continue  # already initialised
            cls = _PROVIDER_CLASSES.get(name)
            if cls is None:
                logger.warning(f"[Router] Unknown provider '{name}' — skipping.")
                continue
            try:
                self._providers[name] = cls(self._config)
                logger.info(f"[Router] Provider ready: {name}")
            except ProviderAuthError as exc:
                logger.warning(f"[Router] {name} skipped — auth error: {exc}")
            except ProviderError as exc:
                logger.warning(f"[Router] {name} skipped — error: {exc}")

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def generate(
        self,
        messages: list[Message],
        system_prompt: str = "",
        max_tokens: int | None = None,
        temperature: float | None = None,
    ) -> str:
        """
        Generate a response using the best available provider.
        Falls back automatically on rate-limit errors.
        """
        mt   = max_tokens  if max_tokens  is not None else self._max_tokens
        temp = temperature if temperature is not None else self._temperature

        # Determine attempt order
        order = [self._default_name]
        if self._fallback_name != self._default_name:
            order.append(self._fallback_name)

        last_error: Exception | None = None

        for name in order:
            provider = self._providers.get(name)
            if provider is None:
                logger.warning(f"[Router] Provider '{name}' not available — skipping.")
                continue

            try:
                logger.info(f"[Router] Using provider: {name}")
                return provider.generate(messages, system_prompt, mt, temp)

            except ProviderRateLimitError as exc:
                print(f"\n[{name}] Rate limit reached — trying fallback provider...")
                logger.warning(f"[Router] {name} rate-limited, trying next provider.")
                last_error = exc
                continue  # try next provider in order

            except ProviderAuthError as exc:
                print(f"\n[{name}] Authentication error — check your API key in settings.json.")
                logger.error(f"[Router] {name} auth error: {exc}")
                last_error = exc
                continue

            except ProviderError as exc:
                print(f"\n[{name}] Provider error: {exc}")
                logger.error(f"[Router] {name} error: {exc}")
                last_error = exc
                continue

        # All providers failed
        raise ProviderError(
            f"All providers failed. Last error: {last_error}"
        )

    def status(self) -> dict[str, bool]:
        """Return a dict showing which providers are available."""
        return {name: (name in self._providers) for name in _PROVIDER_CLASSES}

    @property
    def available_providers(self) -> list[str]:
        return list(self._providers.keys())
