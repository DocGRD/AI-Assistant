"""
Assistant Core — Milestone 2
Adds the AI Provider Layer on top of the Milestone 1 foundation.

What's new in Milestone 2:
    - ProviderRouter initialised at startup
    - Provider status shown in startup diagnostics
    - Real chat loop: input goes to AI, AI replies
    - Conversation history maintained for the session
    - Rate-limit and auth errors handled gracefully
    - 'status' command shows provider health
    - 'clear' command resets conversation history
"""

from pathlib import Path

from config.config_manager import ConfigManager
from config.logger import setup_logger
from providers.provider_router import ProviderRouter
from providers.base_provider import Message, ProviderError


# ---------------------------------------------------------------------------
# Startup Diagnostics
# ---------------------------------------------------------------------------

def run_startup_diagnostics(config: ConfigManager, router: ProviderRouter, logger) -> None:
    """Run startup diagnostics and display system readiness."""
    checks = {}

    # Config file
    config_path = Path(__file__).parent / "config" / "settings.json"
    checks["Config Loaded"] = config_path.exists()

    # Vault
    vault_path = config.get("vault_path", "")
    vault_ok = bool(vault_path) and Path(vault_path).exists()
    checks["Vault Found"] = vault_ok

    # Logs directory
    logs_dir = Path(__file__).parent / "logs"
    logs_dir.mkdir(exist_ok=True)
    checks["Logs Ready"] = logs_dir.exists()

    # Memory directory
    memory_dir = Path(__file__).parent / "memory"
    memory_dir.mkdir(exist_ok=True)
    checks["Memory Ready"] = memory_dir.exists()

    # Provider availability
    provider_status = router.status()
    for provider_name, available in provider_status.items():
        checks[f"Provider: {provider_name.capitalize()}"] = available

    # Display
    print("\n" + "=" * 40)
    print("  AI ASSISTANT — Startup Check")
    print("=" * 40)
    for check_name, passed in checks.items():
        symbol = "✓" if passed else "✗"
        print(f"  {symbol}  {check_name}")
    print("=" * 40)

    available = router.available_providers
    if available:
        print(f"\n  Active provider : {config.get('default_provider', 'groq').upper()}")
        if len(available) > 1:
            print(f"  Fallback provider: {config.get('fallback_provider', 'google').upper()}")
    else:
        print("\n  ✗  No providers available. Add API keys to config/settings.json.")

    print("\n  Assistant Online")
    print("=" * 40 + "\n")

    failed = [n for n, p in checks.items() if not p]
    if failed:
        logger.warning(f"Startup checks failed: {', '.join(failed)}")
    else:
        logger.info("All startup checks passed")


# ---------------------------------------------------------------------------
# System Prompt
# ---------------------------------------------------------------------------

SYSTEM_PROMPT = """You are a helpful AI development assistant integrated with Obsidian.
You help with software development, research, planning, and knowledge management.
You are concise, accurate, and practical.
When you don't know something, say so clearly.
When the user asks you to search the internet, you will generate an optimized research prompt they can paste into a web-based AI instead."""


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> None:
    # Load configuration
    config = ConfigManager()
    logger = setup_logger(config.get("log_level", "INFO"))
    logger.info("Assistant starting — Milestone 2")

    # Initialise provider router
    router = ProviderRouter(config.all())

    # Startup diagnostics
    run_startup_diagnostics(config, router, logger)

    # Check that at least one provider is ready
    if not router.available_providers:
        print("No AI providers available.")
        print("Open config/settings.json and add your API keys, then restart.\n")
        print("  Groq  (free): https://console.groq.com")
        print("  Google (free): https://aistudio.google.com/app/apikey\n")
        return

    # Session conversation history
    history: list[Message] = []

    print("Type your message and press Enter.")
    print("Commands: 'exit' | 'quit' | 'clear' (reset history) | 'status'\n")

    while True:
        try:
            user_input = input("You: ").strip()
        except (KeyboardInterrupt, EOFError):
            print("\nExiting.")
            logger.info("Assistant shut down via keyboard interrupt.")
            break

        if not user_input:
            continue

        # Built-in commands
        if user_input.lower() in ("exit", "quit"):
            logger.info("Assistant shutting down.")
            print("Goodbye.")
            break

        if user_input.lower() == "clear":
            history.clear()
            print("[Conversation history cleared]\n")
            continue

        if user_input.lower() == "status":
            status = router.status()
            print("\n--- Provider Status ---")
            for name, available in status.items():
                symbol = "✓" if available else "✗"
                print(f"  {symbol}  {name.capitalize()}")
            print("-----------------------\n")
            continue

        # Add user message to history
        history.append(Message(role="user", content=user_input))
        logger.info(f"User: {user_input[:80]}{'...' if len(user_input) > 80 else ''}")

        # Get AI response
        try:
            reply = router.generate(
                messages=history,
                system_prompt=SYSTEM_PROMPT,
                max_tokens=config.get("max_tokens", 2048),
                temperature=config.get("temperature", 0.7),
            )
        except ProviderError as exc:
            print(f"\n[Error] Could not get a response: {exc}\n")
            logger.error(f"Provider error: {exc}")
            # Remove the user message we just added since we got no reply
            history.pop()
            continue

        # Add assistant reply to history
        history.append(Message(role="assistant", content=reply))
        logger.info(f"Assistant replied ({len(reply)} chars)")

        print(f"\nAssistant: {reply}\n")


if __name__ == "__main__":
    main()
