"""
Logger Setup
Configures logging to both console and rotating file.
"""

import logging
from logging.handlers import RotatingFileHandler
from pathlib import Path


def setup_logger(level: str = "INFO") -> logging.Logger:
    """Return a configured logger that writes to logs/assistant.log."""
    log_level = getattr(logging, level.upper(), logging.INFO)

    logs_dir = Path(__file__).parent.parent / "logs"
    logs_dir.mkdir(exist_ok=True)
    log_file = logs_dir / "assistant.log"

    logger = logging.getLogger("assistant")
    logger.setLevel(log_level)

    if logger.handlers:
        return logger  # already configured — avoid duplicate handlers

    formatter = logging.Formatter(
        "%(asctime)s | %(levelname)-8s | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )

    # File handler (rotates at 1 MB, keeps 3 backups)
    fh = RotatingFileHandler(log_file, maxBytes=1_000_000, backupCount=3, encoding="utf-8")
    fh.setFormatter(formatter)
    logger.addHandler(fh)

    # Console handler
    ch = logging.StreamHandler()
    ch.setFormatter(formatter)
    logger.addHandler(ch)

    return logger
