"""
Assistant Core — Milestone 4 (Episode fix)
Raw session log tracks every real event separately from the trimmed AI context
window, so the episode note always contains the actual conversation.
"""

import logging
from dataclasses import dataclass, field as dc_field
from datetime import datetime as _dt
from pathlib import Path

from config.config_manager import ConfigManager
from config.logger import setup_logger, set_verbose, is_verbose
from providers.provider_router import ProviderRouter
from providers.base_provider import Message, ProviderError
from providers.model_registry import estimate_tokens
from memory.memory_manager import MemoryManager
from memory.context_manager import ContextManager
from tools.tool_registry import ToolRegistry


# ---------------------------------------------------------------------------
# Raw session log — never trimmed, used only for the episode note
# ---------------------------------------------------------------------------

@dataclass
class RawEntry:
    """One event in the session log. Independent of the AI context window."""
    kind:      str         # "chat" | "vault_command" | "remember" | "error"
    timestamp: str = dc_field(default_factory=lambda: _dt.now().strftime("%H:%M"))
    user:      str = ""    # what the user typed
    assistant: str = ""    # assistant reply (chat entries only)
    tool:      str = ""    # tool name (vault_command entries)
    detail:    str = ""    # query/path or error description


def format_episode(raw_log: list[RawEntry]) -> str:
    """
    Render the raw log as clean Markdown for the episode note.
    - Vault loads → one-line note showing the tool and query
    - Real chat   → full user question + assistant reply
    - remember:   → one-line note of the fact
    - errors      → one-line warning
    """
    if not raw_log:
        return "No activity recorded this session."

    lines: list[str] = []
    for entry in raw_log:

        if entry.kind == "vault_command":
            lines.append(
                f"- **{entry.timestamp}** `{entry.tool}` — {entry.detail}"
            )

        elif entry.kind == "remember":
            lines.append(
                f"- **{entry.timestamp}** Remembered: {entry.user}"
            )

        elif entry.kind == "chat":
            lines.append(f"\n**{entry.timestamp} — You:** {entry.user}")
            if entry.assistant:
                reply_lines = entry.assistant.strip().splitlines()
                indented = "\n> ".join(reply_lines)
                lines.append(f"> {indented}")

        elif entry.kind == "error":
            lines.append(f"- **{entry.timestamp}** ⚠ {entry.detail}")

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Startup diagnostics
# ---------------------------------------------------------------------------

def run_startup_diagnostics(config, router, registry, memory, logger) -> None:
    checks = {}

    config_path = Path(__file__).parent / "config" / "settings.json"
    checks["Config Loaded"]   = config_path.exists()

    vault_path = config.get("vault_path", "")
    checks["Vault Found"]     = bool(vault_path) and Path(vault_path).exists()

    logs_dir = Path(__file__).parent / "logs"
    logs_dir.mkdir(exist_ok=True)
    checks["Logs Ready"]      = logs_dir.exists()

    checks["Memory Ready"]    = memory is not None

    for name, available in router.status().items():
        checks[f"Provider: {name.capitalize()}"] = available

    tool_count = len(registry.tool_names) if registry else 0
    checks[f"Vault Tools ({tool_count})"] = tool_count > 0

    print("\n" + "=" * 48)
    print("  AI ASSISTANT — Startup Check")
    print("=" * 48)
    for name, passed in checks.items():
        print(f"  {'✓' if passed else '✗'}  {name}")
    print("=" * 48)

    avail = router.available_providers
    if avail:
        print(f"\n  Active provider  : {config.get('default_provider','groq').upper()}")
        if len(avail) > 1:
            print(f"  Fallback provider: {config.get('fallback_provider','google').upper()}")
    else:
        print("\n  ✗  No providers available. Add API keys to config/settings.json.")

    print("\n  Assistant Online")
    print("=" * 48 + "\n")

    failed = [n for n, p in checks.items() if not p]
    if failed:
        logger.warning(f"Startup checks failed: {', '.join(failed)}")
    else:
        logger.info("All startup checks passed")


# ---------------------------------------------------------------------------
# System prompt
# ---------------------------------------------------------------------------

BASE_SYSTEM_PROMPT = """You are a helpful AI development and study assistant integrated with Obsidian.
You help with software development, Scripture study, research, planning, and knowledge management.
You are concise, accurate, and practical. When you don't know something, say so clearly.
When vault content is provided in the conversation, use it to give specific grounded answers.
When the user asks you to search the internet, generate an optimized research prompt they can paste into a web-based AI instead.
When the user types 'remember: <something>', acknowledge that the fact has been saved."""


def build_system_prompt(memory_context: str) -> str:
    if memory_context.strip():
        return BASE_SYSTEM_PROMPT + "\n\n" + memory_context
    return BASE_SYSTEM_PROMPT


# ---------------------------------------------------------------------------
# Vault command dispatcher
# ---------------------------------------------------------------------------

VAULT_COMMANDS = {
    "vault:read":   ("read_note",        "Usage: vault:read <note name or path>"),
    "vault:search": ("search_vault",     "Usage: vault:search <query>"),
    "vault:list":   ("list_vault",       "Usage: vault:list [subfolder]"),
    "vault:links":  ("get_linked_notes", "Usage: vault:links <note name or path>"),
    "vault:create": ("create_note",      "Usage: vault:create <path>\\n<content>"),
    "vault:update": ("update_note",      "Usage: vault:update <path>\\n<content to append>"),
}

# Read tools inject their output into AI context; write tools do not
READ_TOOLS = {"read_note", "search_vault", "list_vault", "get_linked_notes"}


def handle_vault_command(
    raw: str,
    registry: ToolRegistry,
    history: list[Message],
    raw_log: list[RawEntry],
    logger,
) -> str | None:
    """
    Run a vault: command.
    - Returns output string if it is a vault command.
    - Returns None if the prefix is not recognised.
    - Writes one RawEntry to raw_log (never the full content).
    """
    parts  = raw.split(None, 1)
    prefix = parts[0].lower()

    if prefix not in VAULT_COMMANDS:
        return None

    tool_name, usage = VAULT_COMMANDS[prefix]
    tool_input = parts[1].strip() if len(parts) > 1 else ""

    if not tool_input and tool_name not in ("list_vault",):
        return f"Missing input. {usage}"

    result = registry.run(tool_name, tool_input)

    # Inject into AI context window for read operations
    if result.success and tool_name in READ_TOOLS:
        context_msg = (
            f"[Vault context loaded by tool '{tool_name}']\n\n{result.output}"
        )
        history.append(Message(role="user",      content=context_msg))
        history.append(Message(role="assistant", content="Vault content loaded. Ready to help."))
        logger.info(f"[Vault] '{tool_name}' injected into history")

    # Record a concise one-liner in the raw log (never the full vault content)
    detail = tool_input.splitlines()[0][:120] if tool_input else "(vault root)"
    raw_log.append(RawEntry(
        kind   = "vault_command",
        tool   = tool_name,
        detail = detail,
    ))

    return f"{'✓' if result.success else '✗'} [{tool_name}]\n\n{result.output}"


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> None:
    config  = ConfigManager()
    logger  = setup_logger(config.get("log_level", "INFO"), verbose=False)
    logger.info("Assistant starting — Milestone 4")

    router  = ProviderRouter(config.all())

    vault_path = config.get("vault_path", "")
    registry: ToolRegistry | None = None
    memory:   MemoryManager | None = None
    ctx_mgr:  ContextManager | None = None

    if vault_path and Path(vault_path).exists():
        registry = ToolRegistry(vault_path)
        memory   = MemoryManager(vault_path)
        ctx_mgr  = ContextManager(router.registry)
    else:
        logger.warning("Vault path not set or missing — vault tools and memory disabled.")

    memory_context = memory.load_context() if memory else ""
    system_prompt  = build_system_prompt(memory_context)

    run_startup_diagnostics(config, router, registry, memory, logger)

    if not router.available_providers:
        print("No AI providers available. Add API keys to config/settings.json.\n")
        print("  Groq   (free): https://console.groq.com")
        print("  Google (free): https://aistudio.google.com/app/apikey\n")
        return

    # Two separate lists:
    #   history  — trimmed by ContextManager, sent to AI
    #   raw_log  — never trimmed, written to episode note on exit
    history: list[Message]  = []
    raw_log: list[RawEntry] = []
    tools_used: list[str]   = []

    print("Type your message and press Enter.")
    print("Vault read   : vault:read | vault:search | vault:list | vault:links")
    print("Vault write  : vault:create | vault:update")
    print("Memory       : remember: <fact>")
    print("Info         : tools | models | context | status | verbose on/off")
    print("Session      : clear | exit\n")

    while True:
        try:
            user_input = input("You: ").strip()
        except (KeyboardInterrupt, EOFError):
            print("\nShutting down...")
            break

        if not user_input:
            continue

        # ── Exit ──────────────────────────────────────────────────────────
        if user_input.lower() in ("exit", "quit"):
            print("Writing session memory...")
            break

        # ── Clear ─────────────────────────────────────────────────────────
        if user_input.lower() == "clear":
            history.clear()
            print("[Conversation history cleared — raw session log preserved]\n")
            continue

        # ── Verbose ───────────────────────────────────────────────────────
        if user_input.lower() in ("verbose on", "verbose off"):
            enable = user_input.lower() == "verbose on"
            set_verbose(enable)
            state = "ON — logs appear in console" if enable else "OFF — logs in assistant.log only"
            print(f"[Verbose {state}]\n")
            continue

        # ── Status ────────────────────────────────────────────────────────
        if user_input.lower() == "status":
            print("\n--- Status ---")
            for name, avail in router.status().items():
                print(f"  {'✓' if avail else '✗'}  {name.capitalize()}")
            print(f"  Verbose: {'ON' if is_verbose() else 'OFF'}")
            if ctx_mgr and router.available_providers:
                active = router.available_providers[0]
                print(f"  Context: {ctx_mgr.report(history, active, system_prompt)}")
            print("--------------\n")
            continue

        # ── Models ────────────────────────────────────────────────────────
        if user_input.lower() == "models":
            print(router.capability_report())
            continue

        # ── Context ───────────────────────────────────────────────────────
        if user_input.lower() == "context":
            if ctx_mgr and router.available_providers:
                active = router.available_providers[0]
                print(f"\n  {ctx_mgr.report(history, active, system_prompt)}")
                print(f"  System prompt  : ~{estimate_tokens([], system_prompt)} tokens")
                print(f"  History entries: {len(history)}")
                print(f"  Raw log entries: {len(raw_log)}\n")
            else:
                print("[Context manager not available]\n")
            continue

        # ── Tools ─────────────────────────────────────────────────────────
        if user_input.lower() == "tools":
            if registry is None:
                print("[Vault tools not available — set vault_path in settings.json]\n")
            else:
                print("\n--- Available Tools ---")
                for t in registry.list_tools():
                    print(f"  {t['name']:<22} {t['description']}")
                print("----------------------\n")
            continue

        # ── Remember ──────────────────────────────────────────────────────
        if user_input.lower().startswith("remember:"):
            fact = user_input[len("remember:"):].strip()
            if memory:
                result = memory.remember(fact)
                print(f"\n{result}\n")
                raw_log.append(RawEntry(kind="remember", user=fact))
            else:
                print("[Memory not available — vault path not set]\n")
            continue

        # ── Vault commands ────────────────────────────────────────────────
        if user_input.lower().startswith("vault:"):
            if registry is None:
                print("[Vault tools not available — set vault_path in settings.json]\n")
                continue
            output = handle_vault_command(user_input, registry, history, raw_log, logger)
            if output is not None:
                parts = user_input.split(None, 1)
                tools_used.append(parts[0].lower())
                print(f"\n{output}\n")
                continue

        # ── Normal AI chat ────────────────────────────────────────────────
        # Trim the AI context window before sending — raw_log is untouched
        if ctx_mgr and router.available_providers:
            active_provider = router.available_providers[0]
            history = ctx_mgr.trim(
                history,
                active_provider,
                system_prompt,
                config.get("max_tokens", 2048),
            )

        history.append(Message(role="user", content=user_input))
        logger.info(f"User: {user_input[:80]}{'...' if len(user_input) > 80 else ''}")

        try:
            reply = router.generate(
                messages      = history,
                system_prompt = system_prompt,
                max_tokens    = config.get("max_tokens", 2048),
                temperature   = config.get("temperature", 0.7),
            )
        except ProviderError as exc:
            print(f"\n[Error] {exc}\n")
            logger.error(f"Provider error: {exc}")
            history.pop()
            raw_log.append(RawEntry(kind="error", detail=str(exc)[:120]))
            continue

        history.append(Message(role="assistant", content=reply))
        logger.info(f"Assistant replied ({len(reply)} chars)")
        print(f"\nAssistant: {reply}\n")

        # Record the real exchange in the raw log
        raw_log.append(RawEntry(
            kind      = "chat",
            user      = user_input,
            assistant = reply,
        ))

    # ------------------------------------------------------------------
    # Shutdown: write episode note from raw_log (not from trimmed history)
    # ------------------------------------------------------------------
    logger.info("Assistant shutting down.")

    if memory:
        episode_content  = format_episode(raw_log)
        error_summary    = router.session_error_summary()
        memory.save_episode(
            session_summary = episode_content,
            error_summary   = error_summary,
            tools_used      = list(set(tools_used)),
        )
        print("Session saved to vault. Goodbye.\n")
    else:
        print("Goodbye.\n")


if __name__ == "__main__":
    main()
