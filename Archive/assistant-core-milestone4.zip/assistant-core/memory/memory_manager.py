"""
Memory Manager — Milestone 4B
==============================
Persistent memory stored as plain Markdown inside the Obsidian vault.
All memory is human-readable, searchable, and editable directly in Obsidian.

Memory layout inside the vault (under AI/Memory/):
    User-Profile.md          — static user facts, loaded every session
    Projects/<name>.md       — per-project accumulated knowledge
    Episodes/YYYY-MM-DD.md   — one note per session (written at shutdown)
    Facts/Learned-Facts.md   — things explicitly told to the assistant

The manager is called:
    - At startup  : load_context()  → returns a string injected into system prompt
    - During chat : remember(fact)  → appends to Learned-Facts.md
    - At shutdown : save_episode()  → writes a session summary note
"""

import logging
import time
from datetime import datetime
from pathlib import Path

logger = logging.getLogger("assistant")


class MemoryManager:
    """Reads and writes the vault's AI/Memory/ folder."""

    # Paths relative to vault root
    MEMORY_ROOT   = "AI/Memory"
    PROFILE_FILE  = "AI/Memory/User-Profile.md"
    FACTS_FILE    = "AI/Memory/Facts/Learned-Facts.md"
    PROJECTS_DIR  = "AI/Memory/Projects"
    EPISODES_DIR  = "AI/Memory/Episodes"
    SYSTEM_DIR    = "AI"

    def __init__(self, vault_path: str):
        self._vault = Path(vault_path)
        self._ensure_structure()

    # ------------------------------------------------------------------
    # Startup: ensure the folder structure and seed files exist
    # ------------------------------------------------------------------

    def _ensure_structure(self) -> None:
        """Create the AI/Memory/ folder tree if it doesn't exist yet."""
        dirs = [
            self._vault / "AI" / "Memory" / "Facts",
            self._vault / "AI" / "Memory" / "Projects",
            self._vault / "AI" / "Memory" / "Episodes",
            self._vault / "AI" / "System",
        ]
        for d in dirs:
            d.mkdir(parents=True, exist_ok=True)

        self._seed_profile()
        self._seed_facts()

    def _seed_profile(self) -> None:
        """Create User-Profile.md with a template if it doesn't exist."""
        profile_path = self._vault / self.PROFILE_FILE
        if profile_path.exists():
            return
        profile_path.write_text(
            "# User Profile\n\n"
            "<!-- The assistant reads this file at every startup. -->\n"
            "<!-- Fill in your details so the assistant knows who it is working with. -->\n\n"
            "## Basic Information\n\n"
            "- **Name:** Glenn\n"
            "- **Primary OS:** Windows 11 (Linux planned)\n"
            "- **Python version:** 3.13.2\n\n"
            "## Active Projects\n\n"
            "- AI Assistant for Obsidian (this project)\n\n"
            "## Obsidian Vault Structure\n\n"
            "- 01 - God: Scripture, prayer, memorization\n"
            "- 02 - Marriage: Personal\n"
            "- 03 - Family: Family notes\n"
            "- 04 - Study and Teach: Scripture study, sermon notes (active: 1 John series)\n"
            "- 05 - Personal Growth: Emotions journal\n"
            "- 06 - Projects: Grok projects, technology\n"
            "- AI/: Assistant memory and system files\n\n"
            "## Preferences\n\n"
            "- Bible version: ESV\n"
            "- Hermeneutic: Spirit-led, Calvary Chapel-aligned, literal-contextual\n"
            "- Code style: Beginner-friendly, well-commented\n"
            "- Zero-cost constraint: All AI providers must remain on free tiers\n\n"
            "## Technology Stack\n\n"
            "- AI Assistant: Python 3.13, Groq + Google AI (free tiers)\n"
            "- Note-taking: Obsidian\n"
            "- Editor: VS Code\n",
            encoding="utf-8",
        )
        logger.info("[Memory] Created User-Profile.md template")

    def _seed_facts(self) -> None:
        """Create Learned-Facts.md if it doesn't exist."""
        facts_path = self._vault / self.FACTS_FILE
        if facts_path.exists():
            return
        facts_path.write_text(
            "# Learned Facts\n\n"
            "<!-- Things the assistant has been explicitly told to remember. -->\n"
            "<!-- Added automatically when you type: remember: <fact> -->\n\n",
            encoding="utf-8",
        )
        logger.info("[Memory] Created Learned-Facts.md template")

    # ------------------------------------------------------------------
    # Startup: load context for system prompt injection
    # ------------------------------------------------------------------

    def load_context(self, project: str | None = None) -> str:
        """
        Read memory files and return a string to inject into the system prompt.
        Called once at session start.

        Loads:
            - User Profile (always)
            - Learned Facts (always)
            - Project memory (if project name is provided and file exists)
        """
        parts: list[str] = ["## Persistent Memory\n"]

        # User profile
        profile = self._read_file(self.PROFILE_FILE)
        if profile:
            parts.append("### User Profile\n" + profile)

        # Learned facts
        facts = self._read_file(self.FACTS_FILE)
        if facts and facts.strip() not in ("", "# Learned Facts"):
            parts.append("### Learned Facts\n" + facts)

        # Project memory
        if project:
            project_file = f"{self.PROJECTS_DIR}/{project}.md"
            project_content = self._read_file(project_file)
            if project_content:
                parts.append(f"### Project Memory: {project}\n" + project_content)

        context = "\n\n".join(parts)
        logger.info(
            f"[Memory] Context loaded — "
            f"{len(context)} chars, project='{project or 'none'}'"
        )
        return context

    # ------------------------------------------------------------------
    # During session: remember a fact
    # ------------------------------------------------------------------

    def remember(self, fact: str) -> str:
        """
        Append a fact to Learned-Facts.md.
        Returns a confirmation string to show the user.
        """
        fact = fact.strip()
        if not fact:
            return "Nothing to remember — fact was empty."

        facts_path = self._vault / self.FACTS_FILE
        timestamp  = datetime.now().strftime("%Y-%m-%d %H:%M")
        entry      = f"- [{timestamp}] {fact}\n"

        try:
            with open(facts_path, "a", encoding="utf-8") as fh:
                fh.write(entry)
            logger.info(f"[Memory] Remembered: {fact[:60]}")
            return f"✓ Remembered: {fact}"
        except Exception as exc:
            logger.error(f"[Memory] Failed to write fact: {exc}")
            return f"✗ Could not save fact: {exc}"

    # ------------------------------------------------------------------
    # End of session: save episode note
    # ------------------------------------------------------------------

    def save_episode(
        self,
        session_summary: str,
        error_summary: str = "",
        tools_used: list[str] | None = None,
    ) -> None:
        """
        Write a session episode note to AI/Memory/Episodes/.
        Called at shutdown.
        """
        date_str = datetime.now().strftime("%Y-%m-%d")
        time_str = datetime.now().strftime("%H:%M")
        filename = f"{date_str}.md"
        ep_path  = self._vault / self.EPISODES_DIR / filename

        # Append to today's episode if it exists (multiple sessions per day)
        mode = "a" if ep_path.exists() else "w"

        tools_line = ", ".join(tools_used) if tools_used else "none"

        content = (
            f"\n## Session — {time_str}\n\n"
            f"### Summary\n{session_summary}\n\n"
            f"### Tools Used\n{tools_line}\n\n"
        )
        if error_summary and error_summary != "No errors recorded this session.":
            content += f"### Provider Errors\n```\n{error_summary}\n```\n\n"

        if mode == "w":
            content = f"# Episode — {date_str}\n" + content

        try:
            with open(ep_path, mode, encoding="utf-8") as fh:
                fh.write(content)
            logger.info(f"[Memory] Episode saved: {filename}")
        except Exception as exc:
            logger.error(f"[Memory] Failed to save episode: {exc}")

    # ------------------------------------------------------------------
    # Project memory
    # ------------------------------------------------------------------

    def update_project(self, project: str, content: str) -> str:
        """
        Create or append to a project memory note.
        Returns a confirmation string.
        """
        project_path = self._vault / self.PROJECTS_DIR / f"{project}.md"
        timestamp    = datetime.now().strftime("%Y-%m-%d %H:%M")

        if not project_path.exists():
            header = f"# Project Memory: {project}\n\n"
            project_path.write_text(header, encoding="utf-8")

        entry = f"\n### Update — {timestamp}\n{content.strip()}\n"
        try:
            with open(project_path, "a", encoding="utf-8") as fh:
                fh.write(entry)
            logger.info(f"[Memory] Project '{project}' updated")
            return f"✓ Project memory '{project}' updated."
        except Exception as exc:
            logger.error(f"[Memory] Failed to update project '{project}': {exc}")
            return f"✗ Could not update project memory: {exc}"

    def list_projects(self) -> list[str]:
        """Return names of all project memory notes."""
        projects_dir = self._vault / self.PROJECTS_DIR
        return [p.stem for p in projects_dir.glob("*.md")]

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _read_file(self, rel_path: str) -> str:
        """Read a vault-relative path; return empty string on any failure."""
        full_path = self._vault / rel_path
        if not full_path.exists():
            return ""
        try:
            return full_path.read_text(encoding="utf-8")
        except Exception as exc:
            logger.warning(f"[Memory] Could not read {rel_path}: {exc}")
            return ""
